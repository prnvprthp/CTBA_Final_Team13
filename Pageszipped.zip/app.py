from dash import Dash, dcc, html, page_container
import dash_bootstrap_components as dbc

#initialize the app
app = Dash(__name__, use_pages=True, external_stylesheets=[dbc.themes.FLATLY], title="CTBA Final App")
server = app.server ##for deployment


app.layout = html.Div([
    dbc.NavbarSimple(
        children=[
            dbc.NavLink("Home", href="/", active="exact"),
            dbc.NavLink("Page 1", href="/FinalPage1", active="exact"), 
            dbc.NavLink("Page 2", href="/FinalPage2", active="exact"), 
            dbc.NavLink("Page 3", href="/FinalPage3", active="exact")
        ],
        brand = "CTBA Final Dash App"
    ), 
    page_container
    
])

if __name__ == "__main__":
    app.run(debug=True)